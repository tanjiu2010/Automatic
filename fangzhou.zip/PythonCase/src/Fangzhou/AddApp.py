'''
Created on 2017年9月5日

@author: Administrator
'''
import unittest
from  selenium  import  webdriver
from Fangzhou import Login

class AddApp(unittest.TestCase):


    def setUp(self):
        self.driver= webdriver.Chrome()
        
        
    def  testAddApp(self):
        
        driver=self.driver
        Login.Login(driver)
        
        driver.implicitly_wait(10)
        driver.find_element_by_partial_link_text("进入我的应用").click()
        driver.implicitly_wait(10)
        driver.find_element_by_xpath("//div[@class='add-app']/i").click()
        driver.find_element_by_xpath("//*[@id='add-firstapplication']/div[3]/div/div/div[2]/div/div[1]/div[2]/input").send_keys("自动化测试APP")
        driver.implicitly_wait(10)
        driver.find_element_by_xpath("//*[@id='add-firstapplication']/div[3]/div/div/div[2]/div/div[3]/div[2]/div/div[1]/div/input").click()
        driver.implicitly_wait(10)
        driver.find_element_by_xpath("//*[@id='add-firstapplication']/div[3]/div/div/div[2]/div/div[3]/div[2]/div/div[2]/div[1]/input").send_keys("综合电商")
        driver.implicitly_wait(10)
        driver.find_element_by_xpath("//*[@id='add-firstapplication']/div[3]/div[1]/div/div[2]/div/div[3]/div[2]/div/div[2]/div[1]/i").click()
        driver.implicitly_wait(10)
        driver.find_element_by_xpath("//*[@id='add-firstapplication']/div[3]/div[1]/div/div[2]/div/div[3]/div[2]/div/div[2]/div[2]/ul/div/li/span/font").click()
        driver.implicitly_wait(10)
        driver.find_element_by_xpath("//*[@id='add-firstapplication']/div[3]/div[1]/div/div[3]/button[2]").click()
        driver.implicitly_wait(10)
        driver.find_element_by_class_name("add_key_start").click()
        driver.implicitly_wait(10)
        driver.find_element_by_xpath("//*[@id='add-firstapplication']/div[1]/div/div[1]/a").click()
        driver.implicitly_wait(30)
        self.assertEqual("自动化测试APP", driver.find_element_by_xpath("//*[@id='add-firstapplication']/div[2]/table/tbody/tr[2]/td[1]/div/div[2]/div[1]/span").text, "创建应用失败")
        driver.implicitly_wait(30)
    def tearDown(self):
        self.driver.quit()

if __name__ == "__main__":
    #import sys;sys.argv = ['', 'Test.testName']
    unittest.main()