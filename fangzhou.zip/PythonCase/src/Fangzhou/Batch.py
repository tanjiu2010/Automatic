'''
Created on 2017年8月3日

@author: Administrator
'''
import unittest
import time,os
from HTMLTestRunner import HTMLTestRunner


from  Fangzhou  import Demo
from  Fangzhou  import AddApp
from  Fangzhou  import DeleteApp
from  Fangzhou  import CreareMessage
from  Fangzhou  import CreateCrowd
from  Fangzhou  import DeleteCrowd
from  Fangzhou  import DeleteMessage
from  Fangzhou  import login


    



if __name__ == '__main__':
       
    suite = unittest.TestSuite()

    suite.addTest(Demo.Demo('testDemo'))
    suite.addTest(login.Login('testLogin'))
    suite.addTest(AddApp.AddApp('testAddApp'))
    suite.addTest(DeleteApp.DeleteApp('testDeleteApp'))
    suite.addTest(CreareMessage.CreatMessage('testCreatMessge'))
    suite.addTest(DeleteMessage.DeleteMessage('testDeleteMessage'))
    suite.addTest(CreateCrowd.CreateCrowd('testCreateCrowd'))
    suite.addTest(DeleteCrowd.DeleteCrowd('testDeleteCrowd'))
    
    #runner = unittest.TextTestRunner()
    #runner.run(suite)
    
    now = time.strftime("%Y-%m-%d %H_%M_%S")   
    filename = 'D:\\pythontest\\TestReport' + str(now) + 'result.html'

    
    print(filename)
     
    fb = open(filename,'wb') 

    runner = HTMLTestRunner(stream=fb,title="测试报告",description = "用例执行情况")
        
    runner.run(suite)
    
    fb.close()