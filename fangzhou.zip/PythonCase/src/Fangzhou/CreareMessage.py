'''
Created on 2017年9月7日

@author: Administrator
'''
import unittest
from selenium import webdriver
from selenium.webdriver.common.action_chains import ActionChains
import time
from Fangzhou import Login

class CreatMessage(unittest.TestCase):

     
    def setUp(self):
        self.driver= webdriver.Chrome()
        
        
    def  testCreatMessge(self):
        
        driver=self.driver
        Login.Login(driver)
        
        driver.implicitly_wait(10)
        ActionChains(driver).move_to_element(driver.find_element_by_id("loginName")).perform()
        driver.implicitly_wait(30)
        
        driver.find_element_by_id("myAppHref").click()  
        driver.implicitly_wait(30)
        
        ActionChains(driver).move_to_element(driver.find_element_by_xpath("//a[@class='act-4-parent']")).perform()
        driver.find_element_by_xpath("//a[@href='/view/message/index.html']").click()
        
        driver.implicitly_wait(30)
        
     
        driver.find_element_by_xpath("//div[@class='add_button']/i").click()
        time.sleep(2)
        
        driver.find_element_by_id("activityname").send_keys("自动化测试通知立即推送")
        
        driver.implicitly_wait(10)
        driver.find_element_by_xpath("//*[@id='creat']/div[2]/div[1]/div[2]/div[2]/ul/li[1]/div/div").click()
        driver.implicitly_wait(10)
       
       
        #切换iframe
        driver.switch_to.frame(driver.find_element_by_id("editor_ifr"))

        
        driver.implicitly_wait(10)
        driver.find_element_by_xpath("//*[@id='tinymce']").send_keys("test")
        driver.switch_to.default_content()

       
        
        driver.implicitly_wait(10)
        
        driver.find_element_by_xpath("//input[@id='sendAddr']").send_keys("test@qq.com")
        driver.implicitly_wait(10)
        
        driver.find_element_by_id("signature").send_keys("test")
        driver.implicitly_wait(30)
        
        driver.find_element_by_id("psTitle").send_keys("test")
        driver.implicitly_wait(30)
        
        driver.find_element_by_xpath("//*[@id='creat']/div[2]/div[2]/div[3]/div[2]/div/div/div/div[1]/div/input").click()
        driver.implicitly_wait(30)
        
        driver.find_element_by_xpath("//*[@id='creat']/div[2]/div[2]/div[3]/div[2]/div/div/div/div[2]/ul/li[1]/font").click()
        driver.implicitly_wait(30)
         
        driver.find_element_by_xpath("//*[@id='creat']/div[2]/div[2]/div[2]/div[3]/div[2]/button[1]/span").click()
        driver.implicitly_wait(40)
        # self.assertEqual("自动化测试通知立即推送", driver.find_element_by_xpath("//*[@id='table']/tbody[1]/tr/td[2]/span").text, "创建消息失败")
        driver.implicitly_wait(30)  
          
    def tearDown(self):
        self.driver.quit()
        

if __name__ == "__main__":
    unittest.main()