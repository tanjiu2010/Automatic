'''
Created on 2017年9月22日

@author: Administrator
'''
import unittest
from selenium import webdriver
from selenium.webdriver.common.action_chains import ActionChains
from Fangzhou import Login

class CreateCrowd(unittest.TestCase):


    def setUp(self):
        self.driver= webdriver.Chrome()
        
        
    def  testCreateCrowd(self):
        
        driver=self.driver
        Login.Login(driver)

        driver.implicitly_wait(30)
        ActionChains(driver).move_to_element(driver.find_element_by_id("loginName")).perform()
        driver.implicitly_wait(30)
        
        driver.find_element_by_id("myAppHref").click()  
        driver.implicitly_wait(30)
        

        driver.find_element_by_xpath("//*[@id='shortcut-menu']/ul/li[3]/a/i").click()
        driver.implicitly_wait(30)
        
        driver.find_element_by_xpath("//*[@id='crowd']/div[1]/div[2]/i").click()
        driver.implicitly_wait(10)
        
        driver.find_element_by_xpath("//*[@id='add-user-group']/div[2]/div[1]/label/input").send_keys("自动化测试人群")
        driver.implicitly_wait(10)
        
        driver.find_element_by_xpath("//*[@id='add-user-group']/div[2]/div[2]/div/div/div[1]/button/span").click()
        driver.implicitly_wait(10)
        
        ActionChains(driver).move_to_element(driver.find_element_by_xpath("//*[@id='add-user-group']/div[2]/div[2]/div/div/div[2]/div/ul/li[1]/label")).perform()
        driver.implicitly_wait(10)
        driver.find_element_by_xpath("//*[@id='add-user-group']/div[2]/div[2]/div/div/div[2]/div/ul/li[1]/ul/li[1]").click()
        driver.implicitly_wait(10)
        

        
        driver.find_element_by_xpath("//*[@id='add-user-group']/div[3]/button/span").click()
        driver.implicitly_wait(30)
        # self.assertEqual("自动化测试人群", driver.find_element_by_xpath("//*[@id='crowd']/div[2]/div[1]/table/tbody/tr[1]/td[1]/div/span[2]").text, "创建人群失败")
        driver.implicitly_wait(30) 
        
        
    def tearDown(self):
        self.driver.quit()    
        
        
        


if __name__ == "__main__":
    #import sys;sys.argv = ['', 'Test.testName']
    unittest.main()