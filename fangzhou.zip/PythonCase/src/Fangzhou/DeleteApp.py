'''
Created on 2017年9月6日

@author: Administrator
'''
import unittest
from selenium import  webdriver
from selenium.webdriver.common.action_chains import ActionChains
from Fangzhou import  Login

class DeleteApp(unittest.TestCase):


    def setUp(self):
        self.driver= webdriver.Chrome()
        
        
    def  testDeleteApp(self):
        
        driver=self.driver
        Login.Login(driver)
        
        driver.implicitly_wait(30)
        driver.find_element_by_partial_link_text("进入我的应用").click()
        driver.implicitly_wait(30)
        
        ActionChains(driver).move_to_element(driver.find_element_by_xpath("//*[@id='add-firstapplication']/div[2]/table/tbody/tr[2]/td[1]/div/div[2]/div[1]/span")).perform()
        
        driver.find_element_by_xpath("//*[@id='add-firstapplication']/div[2]/table/tbody/tr[2]/td[1]/div/div[3]/div[2]/div[1]/i").click()
        driver.implicitly_wait(30)
        driver.find_element_by_xpath("//*[@id='add-firstapplication']/div[5]/div/div[3]/button[2]/span").click()
        driver.implicitly_wait(30)
        #self.assertEqual("易观方舟后台管理", driver.find_element_by_xpath("//*[@id=‘add-firstapplication’]/div[2]/table/tbody/tr[3]/td[1]/div/div[2]/div[1]/span").text, "删除应用失败")

    def tearDown(self):
        self.driver.quit()

if __name__ == "__main__":

    unittest.main()