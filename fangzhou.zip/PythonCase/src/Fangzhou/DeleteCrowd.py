'''
Created on 2018年3月29日

@author: Administrator
'''
import unittest
from selenium import webdriver
from selenium.webdriver.common.action_chains import ActionChains
from Fangzhou import  Login
import time

class DeleteCrowd(unittest.TestCase):


    def setUp(self):
        self.driver= webdriver.Chrome()
        
        
    def  testDeleteCrowd(self):
        
        driver=self.driver
        Login.Login(driver)
        
        driver.implicitly_wait(10)
        ActionChains(driver).move_to_element(driver.find_element_by_id("loginName")).perform()
        driver.implicitly_wait(30)
        
        driver.find_element_by_id("myAppHref").click()  
        driver.implicitly_wait(30)
        

        driver.find_element_by_xpath("//*[@id='shortcut-menu']/ul/li[3]/a/i").click()
        driver.implicitly_wait(30)
        

        driver.implicitly_wait(10)
      
        ActionChains(driver).move_to_element(driver.find_element_by_xpath("//*[@id='crowd']/div[2]/div[1]/table/tbody/tr[1]/td[1]/div/span[2]")).perform()
        driver.find_element_by_xpath("//*[@id='crowd']/div[2]/div[1]/table/tbody/tr[1]/td[1]/div/span[3]/div[3]/div[1]/div/div[1]/i").click()
        driver.implicitly_wait(30)
        time.sleep(5)
        
        driver.find_element_by_xpath("//*[@id='crowd']/div[2]/div[1]/table/tbody/tr[1]/td[1]/div/span[3]/div[3]/div[2]/div/div[2]/div[2]/button[2]/span").click()
        driver.implicitly_wait(10)
        
        driver.implicitly_wait(30) 
        
        
    def tearDown(self):
        self.driver.quit()    
        
        
        


if __name__ == "__main__":

    unittest.main()
        