'''
Created on 2018年3月29日

@author: Administrator
'''
import unittest
from selenium import webdriver
from selenium.webdriver.common.action_chains import ActionChains
from Fangzhou import Login

class DeleteMessage(unittest.TestCase):

     
    def setUp(self):
        self.driver= webdriver.Chrome()
        
        
    def  testDeleteMessage(self):
        
        driver=self.driver
        Login.Login(driver)
        
        driver.implicitly_wait(10)
        ActionChains(driver).move_to_element(driver.find_element_by_id("loginName")).perform()
        driver.implicitly_wait(30)
        
        driver.find_element_by_id("myAppHref").click()  
        driver.implicitly_wait(30)
        
        ActionChains(driver).move_to_element(driver.find_element_by_xpath("//a[@class='act-4-parent']")).perform()
        driver.find_element_by_xpath("//a[@href='/view/message/index.html']").click()
        
        driver.implicitly_wait(30)
        
        ActionChains(driver).move_to_element(driver.find_element_by_xpath("//*[@id='table']/tbody[1]/tr/td[8]")).perform()
        driver.find_element_by_xpath("//*[@id='table']/tbody[1]/tr/td[8]/span[2]/div[3]/div[1]/i").click()
        driver.implicitly_wait(10)
        driver.find_element_by_xpath("//*[@id='app']/div[3]/div/div[3]/button[2]/span").click()
        driver.implicitly_wait(30)
        
    def tearDown(self):
        self.driver.quit()    
        
        
        
if __name__ == "__main__":

    unittest.main() 