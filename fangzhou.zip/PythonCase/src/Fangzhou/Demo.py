'''
Created on 2017年8月14日

@author: Administrator
'''
import unittest
from  selenium  import  webdriver

class   Demo(unittest.TestCase):
    
    def setUp(self):
        
        self.driver= webdriver.Chrome()
        self.driver.maximize_window()
        self.driver.get("https://testark.analysys.cn/")
        self.driver.implicitly_wait(10)



    def testDemo(self):
        
        driver=self.driver    
        driver.find_element_by_id("jDemoBtn").click()
        driver.implicitly_wait(3)
        self.assertEqual("看板_易观方舟", driver.title, "跳转demo应用失败")
        driver.find_element_by_partial_link_text("各渠道新增用户趋势")
        
        driver.find_element_by_css_selector("#vue-memu > ul > li:nth-child(2) > label > span").click()
        driver.implicitly_wait(10)
        driver.find_element_by_partial_link_text("新增用户留存趋势")
        
        
        driver.find_element_by_css_selector("#vue-memu > ul > li:nth-child(3) > label > span").click()
        driver.implicitly_wait(10)
        driver.find_element_by_partial_link_text("申请试用路径转化漏斗")
        
        driver.find_element_by_css_selector("#vue-memu > ul > li:nth-child(4) > label > span").click()
        driver.implicitly_wait(10)
        driver.find_element_by_partial_link_text("设备品牌分布")
        
        driver.find_element_by_css_selector("#vue-memu > ul > li:nth-child(5) > label > span").click()
        driver.implicitly_wait(10)
        driver.find_element_by_partial_link_text("用户出行用车类APP的使用偏好")
        
        driver.find_element_by_css_selector("#vue-memu > ul > li:nth-child(6) > label > span").click()
        driver.implicitly_wait(10)
        driver.find_element_by_partial_link_text("不同活动激活的用户趋势")
        
        driver.find_element_by_css_selector("#vue-memu > ul > li:nth-child(7) > label > span").click()
        driver.find_element_by_partial_link_text("近30日活跃用户趋势")
        driver.implicitly_wait(10)
        
    def tearDown(self):
        self.driver.quit()

if __name__ == "__main__":

    unittest.main()