

from  selenium import webdriver


    
def  Login(driver):
    
    driver.maximize_window()
    driver.get("https://testark.analysys.cn/")
    driver.implicitly_wait(10)
    
    driver.find_element_by_partial_link_text("登录").click()
    driver.implicitly_wait(10)
        
    driver.find_element_by_id("f-user").send_keys("1445383758@qq.com")
    driver.implicitly_wait(10)
    driver.find_element_by_id("f-code").send_keys("123456")
    driver.implicitly_wait(10)
    driver.find_element_by_xpath("//*[@id='app']/form/div[3]/button").click()
        


        
